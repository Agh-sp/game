"""دروازه احراز هویت ربات ادمین + سطح‌بندی دسترسی."""
from aiogram import BaseMiddleware
from aiogram.types import CallbackQuery, Message

from core.db import db
from core.utils import jloads

ALL_PERMS = [
    "users", "economy", "countries", "military", "world", "projects",
    "un", "missions", "tickets", "settings", "broadcast", "logs", "admins",
    "trade", "media", "seasons",
]

PERM_TITLES = {
    "users": "👥 کاربران", "economy": "🪙 اقتصاد و پرداخت", "countries": "🏳 کشورها",
    "military": "🪖 نظامی", "world": "🌍 دنیا و قوانین", "projects": "🏢 شرکت‌ها و پروژه‌ها",
    "un": "🗳 سازمان ملل و جنگ‌ها", "missions": "🎯 ماموریت‌ها", "tickets": "🎫 پشتیبانی",
    "settings": "⚙️ تنظیمات", "broadcast": "📣 پیام همگانی", "logs": "📜 لاگ‌ها",
    "admins": "🛡 مدیریت ادمین‌ها", "trade": "🤝 تجارت و پیمان‌ها",
    "media": "🖼 کتابخانه تصاویر", "seasons": "🎬 سیزن‌ها",
}


class AdminGate(BaseMiddleware):
    """فقط ادمین‌های ثبت‌شده اجازه استفاده از ربات ادمین را دارند."""

    async def __call__(self, handler, event, data):
        user = getattr(event, "from_user", None)
        if user is None or user.is_bot:
            return
        admin = await db.fetchone("SELECT * FROM admins WHERE id=?", (user.id,))
        if not admin:
            if isinstance(event, Message):
                await event.answer(
                    "⛔️ <b>شما ادمین نیستید.</b>\n\n"
                    f"🆔 آیدی عددی شما: <code>{user.id}</code>\n"
                    "این آیدی را به سوپرادمین بدهید تا شما را ادمین کند.")
            elif isinstance(event, CallbackQuery):
                await event.answer("⛔️ شما ادمین نیستید", show_alert=True)
            return
        perms = set(jloads(admin["perms"], []))
        if admin["is_super"]:
            perms = set(ALL_PERMS) | {"*"}
        data["admin"] = admin
        data["perms"] = perms
        return await handler(event, data)


def has(perms: set, perm: str) -> bool:
    return "*" in perms or perm in perms
