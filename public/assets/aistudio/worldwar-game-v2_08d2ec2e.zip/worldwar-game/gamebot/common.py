"""ابزارهای مشترک ربات اصلی: کیبوردها، گاردها و نمایش کشور.

نکته مهم: تابع kb() به‌طور خودکار دکمه «🏰 بازگشت به امپراطوری من» را
زیر همه پیام‌های ربات اضافه می‌کند (اگر خودش تکراری نباشد).
"""
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from core.db import db, get_setting
from core.economy import army_power, get_country, get_state, my_gov_religion
from core.firebase import fb
from core.utils import fmt, hours_left, fmt_hm, is_past

# ─── ساخت کیبورد ───

HOME_BTN = ("🏰 بازگشت به امپراطوری من", "g|emp")


def kb(rows: list[list[tuple[str, str]]], home: bool = True) -> InlineKeyboardMarkup:
    """ساخت اینلاین کیبورد: [(متن، کالبک), ...]

    home=True → دکمه «بازگشت به امپراطوری من» زیر همه پیام‌ها اضافه می‌شود
    (مگر خود کیبورد دکمه g|emp داشته باشد).
    """
    rows = [list(r) for r in rows if r]
    if home:
        flat = [c for r in rows for (_t, c) in r if isinstance(c, str)]
        if "g|emp" not in flat:
            rows.append([HOME_BTN])
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text=t, callback_data=c) for t, c in row]
            for row in rows
        ]
    )


def back_row(callback: str, text: str = "◀️ بازگشت") -> list[tuple[str, str]]:
    return [(text, callback)]


def home_row() -> list[tuple[str, str]]:
    return [("🏠 منو شروع", "g|main")]


async def send_home(message, text: str, **kw):
    """ارسال پیام متنی با دکمه «بازگشت به امپراطوری من» (اگر کیبورد دیگری داده نشد)."""
    rm = kw.pop("reply_markup", None)
    if rm is None:
        rm = kb([])
    return await message.answer(text, reply_markup=rm, **kw)


async def dm(bot, chat_id, text: str, **kw):
    """ارسال پیام خصوصی به بازیکن دیگر با دکمه «بازگشت به امپراطوری من» (خطا بی‌خطر)."""
    rm = kw.pop("reply_markup", None)
    if rm is None:
        rm = kb([])
    try:
        return await bot.send_message(chat_id, text, reply_markup=rm, **kw)
    except Exception:
        return None


# ─── عضویت اجباری ───


async def check_membership(bot, user_id: int) -> bool:
    channels = await get_setting("join_channels", "[]")
    if not channels or channels == "[]":
        return True
    import json
    try:
        chans = json.loads(channels)
    except ValueError:
        return True
    for ch in chans:
        try:
            member = await bot.get_chat_member(chat_id=ch, user_id=user_id)
            if member.status not in ("member", "administrator", "creator"):
                return False
        except Exception:
            return False
    return True


async def join_keyboard() -> InlineKeyboardMarkup:
    import json
    chans = []
    try:
        chans = json.loads(await get_setting("join_channels", "[]"))
    except ValueError:
        pass
    rows = [[(f"📢 {ch}", f"https://t.me/{ch.lstrip('@')}", "url")] for ch in chans]
    rows.append([("🔍 بررسی عضویت", "g|chk")])
    out = []
    for row in rows:
        btns = []
        for item in row:
            text, data, kind = item
            if kind == "url":
                btns.append(InlineKeyboardButton(text=text, url=data))
            else:
                btns.append(InlineKeyboardButton(text=text, callback_data=data))
        out.append(btns)
    return InlineKeyboardMarkup(inline_keyboard=out)


# ─── نمایش کشور ───


async def country_display(user_id: int, extended: bool = False) -> str:
    user = await db.fetchone("SELECT * FROM users WHERE id=?", (user_id,))
    country = await get_country(user_id)
    if not user or not country:
        return "🏳 کشور ندارید"
    state = await get_state(user_id)
    gov, rel = await my_gov_religion(user_id)
    atk, dfn, cyb = await army_power(user_id)
    flag = f"{country['flag']}"
    if gov and gov.get("flag"):
        flag = f"{country['flag']}{gov['flag']}"
    main_cur = await get_setting("main_currency", "")
    lines = [
        f"{flag} <b>{country['name']}</b>",
        f"👤 رهبر: {user['full_name'] or user['id']}",
        f"😊 رضایت مردم: <b>{round(state['satisfaction'] or 0)}/100</b>",
        f"💰 خزانه: <b>{fmt(user['money'])}</b> (💵 ارز کشور: {state.get('currency_name') or '—'}"
        + (f" | پول اصلی بازی: {main_cur}" if main_cur else "") + ")",
        f"🪙 سکه شاهی: <b>{fmt(user['royal_coins'])}</b>",
        f"👥 جمعیت: <b>{fmt(country['population'])}</b>",
        f"⚔️ حمله: <b>{fmt(atk)}</b> | 🛡 دفاع: <b>{fmt(dfn)}</b> | 🕶 سایبر: <b>{fmt(cyb)}</b>",
        f"⛪ دین: <b>{rel['name'] if rel else '—'}</b> | 🏛 حکومت: <b>{gov['name'] if gov else '—'}</b>",
    ]
    if extended:
        from core.straits import naval_power, my_straits
        lines += [
            f"⚓ قدرت دریایی: <b>{fmt(await naval_power(user_id))}</b> | تنگه‌های من: <b>{len(await my_straits(user_id))}</b>",
            f"🛢 نفت انبار: <b>{fmt(state.get('oil_stock') or 0)}</b> بشکه | مخزن زیرزمینی: <b>{fmt(country.get('oil_reserve') or 0)}</b>",
            f"⚡️ انرژی: <b>{fmt(state.get('energy') or 0)}</b> kWh | 💧 آب: <b>{fmt(state.get('water') or 0)}</b> | 🔥 گاز: <b>{fmt(state.get('gas') or 0)}</b>",
            f"🕊 دیپلماسی: <b>{round(state.get('diplomacy') or 50)}/100</b>",
        ]
    return "\n".join(lines)


def blocked_banner(state: dict) -> str:
    """پیام مسدودی ترور رهبر / تداخل سرور."""
    parts = []
    if state.get("server_jam_until") and not is_past(state["server_jam_until"]):
        parts.append(f"📡 <b>سرورهای شما در حال اختلال هستند!</b> ({fmt_hm(hours_left(state['server_jam_until']))} مانده)\n"
                     "تا رفع مشکل فقط می‌توانید بیانیه صادر کنید.")
    elif state.get("leader_block_until") and not is_past(state["leader_block_until"]):
        parts.append(f"🚫 <b>رهبر شما ترور شده!</b> ({fmt_hm(hours_left(state['leader_block_until']))} مانده)\n"
                     "حمله و دیپلماسی مسدود است.")
    return ("\n".join(parts) + "\n\n") if parts else ""


def server_line() -> str:
    """وضعیت اتصال سرور فایربیس‌مانند."""
    try:
        return fb.status_line()
    except Exception:
        return ""


# ─── منوهای اصلی ───


def main_menu_kb() -> InlineKeyboardMarkup:
    return kb([
        [("🏰 امپراطوری من", "g|emp")],
        [("🎯 ماموریت روزانه", "g|mis")],
        [("🪙 سکه شاهی", "g|coin")],
        [("📖 راهنمای بازی", "g|guide")],
        [("🛟 پشتیبانی", "g|sup")],
        [("🔄 تغییر کشور", "g|cchg")],
    ])


def empire_kb() -> InlineKeyboardMarkup:
    return kb([
        [("🏛 مدیریت کشور", "g|mg")],
        [("⚔️ اتاق جنگ", "g|war")],
        [("🤝 تجارت بین‌المللی", "g|trd")],
        [("🕊 سازمان ملل", "g|un")],
        [("🛟 سازمان نجات", "g|resc")],
        [("📢 بیانیه", "g|stmt")],
        home_row(),
    ])


def manage_kb() -> InlineKeyboardMarkup:
    return kb([
        [("👥 مردم", "g|ppl")],
        [("🏗 پروژه ملی", "g|prj")],
        [("🪖 ارتش", "g|army")],
        [("⛪ دین و حکومت", "g|gov")],
        [("🏢 شرکت‌های من", "g|comp")],
        home_row(),
    ])
