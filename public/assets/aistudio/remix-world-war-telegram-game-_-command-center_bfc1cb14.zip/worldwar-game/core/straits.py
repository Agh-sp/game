"""تنگه‌های راهبردی — قدرت دریایی، تصاحب، عوارض ۱.۵٪ درآمد غیرمالیاتی."""
from core.db import db, get_setting
from core.economy import get_country
from core.events import log_event
from core.images import announce_img
from core.utils import fmt, iso


async def naval_power(user_id: int) -> int:
    """قدرت دریایی = مجموع توان (حمله+دفاع) تجهیزات دسته دریایی (ناو/زیردریایی/قایق/...)."""
    rows = await db.fetchall(
        "SELECT a.quantity, (e.attack_power + e.defense_power) AS power FROM player_assets a "
        "JOIN equipment e ON e.id=a.item_id "
        "JOIN equipment_categories c ON c.id=e.category_id "
        "WHERE a.user_id=? AND a.item_type='equipment' AND c.key='sea'", (user_id,))
    return int(sum(r["quantity"] * (r["power"] or 0) for r in rows))


async def my_straits(user_id: int) -> list[dict]:
    return await db.fetchall("SELECT * FROM straits WHERE owner_id=? ORDER BY id", (user_id,))


async def capture_requirements(user_id: int, strait: dict) -> tuple[bool, str]:
    """آیا این کشور می‌تواند تنگه را تصاحب کند؟"""
    country = await get_country(user_id)
    if not country or not country.get("has_sea"):
        return False, "❌ کشور شما مرز دریایی ندارد!"
    my = await naval_power(user_id)
    if not strait["owner_id"] or strait["owner_id"] == user_id:
        need = int(float(await get_setting("strait_min_naval", "500")))
        if my < need:
            return False, f"❌ برای تصاحب تنگه آزاد حداقل {fmt(need)} قدرت دریایی لازم است (شما: {fmt(my)})."
        return True, ""
    if strait["owner_id"] == user_id:
        return False, "شما مالک این تنگه هستید."
    owner_country = await get_country(strait["owner_id"])
    owner_power = await naval_power(strait["owner_id"])
    ratio = float(await get_setting("strait_capture_ratio", "2.5"))
    need = int(owner_power * ratio)
    if my < need:
        return False, (f"❌ برای گرفتن تنگه از {owner_country['name'] if owner_country else 'مالک'} "
                       f"باید حداقل {fmt(need)} قدرت دریایی داشته باشید "
                       f"(۲.۵ برابر قدرت او: {fmt(owner_power)}). شما: {fmt(my)}.")
    return True, ""


async def capture_strait(bot, user_id: int, strait_id: int) -> str:
    """تصاحب تنگه با شرط قدرت دریایی + اعلان کانال با عکس."""
    s = await db.fetchone("SELECT * FROM straits WHERE id=? AND is_active=1", (strait_id,))
    if not s:
        return "تنگه یافت نشد."
    ok, err = await capture_requirements(user_id, s)
    if not ok:
        return err
    old_owner = s["owner_id"]
    old_country = await get_country(old_owner) if old_owner else None
    await db.execute("UPDATE straits SET owner_id=?, captured_at=? WHERE id=?",
                     (user_id, iso(), strait_id))
    me = await get_country(user_id)
    await log_event("strait", f"{me['name']} تنگه {s['name']} را تصاحب کرد")
    if old_owner and old_owner != user_id:
        try:
            await bot.send_message(old_owner,
                                   f"⚔️ کشور {me['flag']} {me['name']} تنگه {s['name']} را از شما گرفت!")
        except Exception:
            pass
    await announce_img(
        bot,
        f"⚓ کشور {me['flag']} {me['name']} با قدرت دریایی، تنگه <b>{s['name']}</b> را تصاحب کرد!\n"
        + (f"مالک قبلی: {old_country['name']}" if old_country else "این تنگه پیش از این بدون مالک بود."),
        "strait")
    return f"✅ تنگه {s['name']} متعلق به شما شد! ۱.۵٪ درآمد غیرمالیاتی کشورهای دارای دریا از این پس به شما می‌رسد."


async def toll_payers_slice(payer_id: int, non_tax_income: float) -> list[tuple[int, int]]:
    """محاسبه عوارض تنگه برای یک پرداخت‌کننده: [(مالک، مبلغ)]."""
    country = await get_country(payer_id)
    if not country or not country.get("has_sea"):
        return []
    pct = float(await get_setting("strait_toll_percent", "1.5")) / 100
    sec_on = await get_setting("sec_straits", "1")
    if sec_on != "1":
        return []
    rows = await db.fetchall(
        "SELECT s.owner_id, c.has_sea FROM straits s JOIN countries c ON c.owner_id=s.owner_id "
        "WHERE s.is_active=1 AND s.owner_id IS NOT NULL AND s.owner_id!=?", (payer_id,))
    out = []
    for r in rows:
        if not r["has_sea"]:  # مالکِ بدون مرز دریایی درآمدی از تنگه نمی‌گیرد
            continue
        out.append((r["owner_id"], int(non_tax_income * pct)))
    return out


async def straits_menu_text(user_id: int) -> tuple[str, list]:
    """متن و دکمه‌های بخش تنگه‌ها."""
    rows_db = await db.fetchall("SELECT * FROM straits WHERE is_active=1 ORDER BY id")
    my = await naval_power(user_id)
    mine = await my_straits(user_id)
    toll = 0
    lines = ["⚓ <b>تنگه‌های راهبردی دنیا</b>\n",
             f"🚢 قدرت دریایی شما: <b>{fmt(my)}</b> (ناو/زیردریایی/قایق/ناوشکن)",
             f"🏝 تنگه‌های شما: <b>{len(mine)}</b>\n"]
    buttons = []
    for s in rows_db:
        owner = await get_country(s["owner_id"]) if s["owner_id"] else None
        if s["owner_id"] == user_id:
            status = "👑 مالک: شما"
        elif owner:
            status = f"🏳 مالک: {owner['flag']} {owner['name']}"
        else:
            status = "🆓 بدون مالک"
        lines.append(f"• {s['emoji']} <b>{s['name']}</b> — {status}")
        if s["owner_id"] != user_id:
            buttons.append([(f"⚔️ تصاحب {s['name']}", f"g|stc|{s['id']}")])
    if mine:
        lines.append("\n💰 عوارض تنگه‌ها: ۱.۵٪ درآمد غیرمالیاتی هر کشورِ دارای دریا (غیر از خودتان) به شما می‌رسد.")
    lines.append("\n⚠️ کشورهای بدون مرز دریایی نه عوارض می‌پردازند و نه درآمد تنگه دارند.")
    return "\n".join(lines), buttons
