"""ابزارهای مدیریت کاربران: پروفایل، سکه/پول، بن، حذف کشور/پژوهش/تجهیزات، ریست، پیام."""
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from adminbot.auth import has
from adminbot.crud import cd, kb
from adminbot.tools import log_action, notify_user
from core.db import db
from core.economy import army_power, get_country
from core.utils import fmt, tehran

router = Router()
PAGE = 8


class UserFSM(StatesGroup):
    search = State()
    amount = State()
    message = State()


@router.message(Command("u"))
async def cmd_user(message: Message, state: FSMContext, perms: set):
    if not has(perms, "users"):
        return await message.answer("⛔️ دسترسی ندارید")
    await state.set_state(UserFSM.search)
    await message.answer(
        "👥 <b>جستجوی کاربر</b>\n\nآیدی عددی، یوزرنیم یا نام کاربر را بفرستید:\n برای انصراف /cancel")


@router.callback_query(F.data == "a|usr")
async def user_search(call: CallbackQuery, state: FSMContext):
    await state.set_state(UserFSM.search)
    await call.answer()
    await call.message.edit_text(
        "👥 <b>جستجوی کاربر</b>\n\nآیدی عددی، یوزرنیم یا نام کاربر را بفرستید:\n برای انصراف /cancel")


@router.message(UserFSM.search)
async def user_search_input(message: Message, state: FSMContext):
    q = (message.text or "").strip().lstrip("@")
    like = f"%{q}%"
    if q.isdigit():
        rows = await db.fetchall(
            "SELECT * FROM users WHERE id=? OR full_name LIKE ? OR username LIKE ? LIMIT 10",
            (int(q), like, like))
    else:
        rows = await db.fetchall(
            "SELECT * FROM users WHERE full_name LIKE ? OR username LIKE ? LIMIT 10", (like, like))
    if not rows:
        return await message.answer("❌ کاربری یافت نشد. دوباره بفرستید یا /cancel")
    if len(rows) == 1:
        await state.clear()
        fake = _FakeCall(message)
        return await user_card(fake, rows[0]["id"])
    lines = ["👥 <b>نتایج جستجو</b>"]
    buttons = []
    for r in rows:
        country = await db.fetchone("SELECT flag, name FROM countries WHERE id=?", (r["country_id"],)) \
            if r["country_id"] else None
        c_txt = f" {country['flag']}{country['name']}" if country else ""
        lines.append(f"• {r['full_name']} <code>{r['id']}</code>{c_txt}")
        buttons.append([(f"{r['full_name']} ({fmt(r['id'])})", f"a|ucard|{r['id']}")])
    buttons.append([("◀️ بازگشت", "a|root")])
    await message.answer("\n".join(lines), reply_markup=kb(buttons))


async def user_card_text(uid: int) -> tuple[str, dict | None]:
    user = await db.fetchone("SELECT * FROM users WHERE id=?", (uid,))
    if not user:
        return "❌ کاربر یافت نشد", None
    country = await get_country(uid)
    atk, dfn, cyb = await army_power(uid)
    state = await db.fetchone("SELECT * FROM states WHERE user_id=?", (uid,))
    assets = await db.fetchone(
        "SELECT COALESCE(SUM(quantity),0) c FROM player_assets WHERE user_id=?", (uid,))
    projects = await db.fetchone(
        "SELECT COUNT(*) c FROM player_projects WHERE user_id=?", (uid,))
    companies = await db.fetchone(
        "SELECT COUNT(*) c FROM companies WHERE owner_id=?", (uid,))
    receipts = await db.fetchone(
        "SELECT COUNT(*) c FROM receipts WHERE user_id=?", (uid,))
    text = (
        f"👤 <b>{user['full_name']}</b>"
        + (f" (@{user['username']})" if user["username"] else "") + "\n"
        f"🆔 <code>{user['id']}</code>\n\n"
        f"🏳 کشور: {country['flag'] + ' ' + country['name'] if country else '—'}\n"
        f"🪙 سکه شاهی: <b>{fmt(user['royal_coins'])}</b>\n"
        f"💰 پول پایه: <b>{fmt(user['money'])}</b>\n"
        + (f"😊 رضایت: <b>{round(state['satisfaction'] or 0)}/100</b>\n" if state else "")
        + f"⚔️ ارتش: حمله {fmt(atk)} | دفاع {fmt(dfn)} | سایبر {fmt(cyb)}\n"
        f"📦 دارایی‌ها: {fmt(assets['c'])} | 🔬 پروژه/پژوهش: {fmt(projects['c'])} | "
        f"🏢 شرکت: {fmt(companies['c'])}\n"
        f"🧾 فیش‌ها: {fmt(receipts['c'])}\n"
        f"🚫 اخراج: {'بله' if user['banned'] else 'خیر'} | 📅 عضویت: {tehran(user['joined_at'])}")
    return text, user


def user_card_kb(uid: int, banned: int) -> list:
    return [
        [("🪙 + سکه شاهی", f"a|ucoin|{uid}|p"), ("🪙 − سکه شاهی", f"a|ucoin|{uid}|m")],
        [("💰 + پول", f"a|umon|{uid}|p"), ("💰 − پول", f"a|umon|{uid}|m")],
        [("🗑 برداشتن کشورش", f"a|ucountry|{uid}")],
        [("🧹 حذف پژوهش‌هایش", f"a|ures|{uid}"), ("🧹 حذف تجهیزاتش", f"a|ueq|{uid}")],
        [("♻️ ریست کامل", f"a|ureset|{uid}")],
        [("✏️ ویرایش خام ردیف", cd("usr", "r", uid))],
        [("✉️ پیام خصوصی", f"a|umsg|{uid}")],
        [("🚫 بن" if not banned else "✅ لغو بن", f"a|uban|{uid}")],
        [("🧾 فیش‌های او", f"a|urcp|{uid}")],
        [("◀️ بازگشت", "a|root")],
    ]


async def user_card(call, uid: int):
    text, user = await user_card_text(uid)
    if not user:
        return await call.answer("کاربر یافت نشد", show_alert=True)
    await call.answer()
    await call.message.edit_text(text, reply_markup=kb(user_card_kb(uid, user["banned"])))


@router.callback_query(F.data.startswith("a|ucard|"))
async def on_user_card(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    await user_card(call, uid)


@router.callback_query(F.data.startswith("a|ucoin|"))
async def user_coin(call: CallbackQuery, state: FSMContext, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    _, _, uid, sign = call.data.split("|")
    await state.set_state(UserFSM.amount)
    await state.update_data(op="coin", uid=int(uid), sign=sign)
    await call.answer()
    await call.message.edit_text(
        f"🪙 مقدار {'افزایش' if sign == 'p' else 'کاهش'} سکه شاهی را بفرستید:\n برای انصراف /cancel")


@router.callback_query(F.data.startswith("a|umon|"))
async def user_money(call: CallbackQuery, state: FSMContext, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    _, _, uid, sign = call.data.split("|")
    await state.set_state(UserFSM.amount)
    await state.update_data(op="money", uid=int(uid), sign=sign)
    await call.answer()
    await call.message.edit_text(
        f"💰 مقدار {'افزایش' if sign == 'p' else 'کاهش'} پول پایه را بفرستید:\n برای انصراف /cancel")


@router.message(UserFSM.amount)
async def user_amount_input(message: Message, state: FSMContext):
    try:
        amount = int((message.text or "").strip().replace(",", ""))
    except ValueError:
        return await message.answer("❌ فقط عدد بفرستید.")
    if amount < 0:
        return await message.answer("❌ عدد نمی‌تواند منفی باشد.")
    data = await state.get_data()
    await state.clear()
    uid, op, sign = data["uid"], data["op"], data["sign"]
    col = "royal_coins" if op == "coin" else "money"
    if sign == "m":
        user = await db.fetchone(f"SELECT {col} AS v FROM users WHERE id=?", (uid,))
        amount = min(amount, user["v"] if user else 0)
        await db.execute(f"UPDATE users SET {col}={col}-? WHERE id=?", (amount, uid))
    else:
        await db.execute(f"UPDATE users SET {col}={col}+? WHERE id=?", (amount, uid))
    label = "سکه شاهی" if op == "coin" else "پول پایه"
    await log_action(message.from_user.id, "کاربر",
                     f"{label} {'+' if sign == 'p' else '-'}{amount} برای {uid}")
    await message.answer(f"✅ {label} کاربر <code>{uid}</code> "
                         f"{'+' if sign == 'p' else '-'}<b>{fmt(amount)}</b> شد.")
    await notify_user(uid, f"🔔 {label} شما توسط ادمین "
                           f"{'افزایش' if sign == 'p' else 'کاهش'} یافت: {fmt(amount)}.")
    await user_card(_FakeCall(message), uid)


@router.callback_query(F.data.startswith("a|uban|"))
async def user_ban(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    user = await db.fetchone("SELECT * FROM users WHERE id=?", (uid,))
    if not user:
        return await call.answer("کاربر یافت نشد", show_alert=True)
    new = 0 if user["banned"] else 1
    await db.execute("UPDATE users SET banned=? WHERE id=?", (new, uid))
    await log_action(call.from_user.id, "کاربر", f"بن={new} برای {uid}")
    await notify_user(uid, "🚫 شما توسط ادمین از بازی اخراج شدید." if new else
                      "✅ حکم اخراج شما لغو شد — welcome back!")
    await call.answer("✅ اعمال شد")
    await user_card(call, uid)


@router.callback_query(F.data.startswith("a|ucountry|"))
async def user_remove_country(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    user = await db.fetchone("SELECT * FROM users WHERE id=?", (uid,))
    if not user or not user["country_id"]:
        return await call.answer("کشوری ندارد", show_alert=True)
    await db.execute("UPDATE countries SET owner_id=NULL WHERE owner_id=?", (uid,))
    await db.execute("UPDATE users SET country_id=NULL, country_taken_at=NULL WHERE id=?", (uid,))
    await db.execute("DELETE FROM player_assets WHERE user_id=?", (uid,))
    await db.execute("DELETE FROM player_projects WHERE user_id=?", (uid,))
    await db.execute("DELETE FROM soldier_trainings WHERE user_id=?", (uid,))
    await db.execute("DELETE FROM companies WHERE owner_id=?", (uid,))
    await db.execute("DELETE FROM bases WHERE guest_id=? OR host_id=?", (uid, uid))
    await log_action(call.from_user.id, "کاربر", f"برداشتن کشور {user['country_id']} از {uid}")
    await notify_user(uid, "🏳 کشور شما توسط ادمین برداشته شد.")
    await call.answer("✅ کشور آزاد شد")
    await user_card(call, uid)


@router.callback_query(F.data.startswith("a|ures|"))
async def user_clear_research(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    await db.execute("DELETE FROM player_projects WHERE user_id=?", (uid,))
    await log_action(call.from_user.id, "کاربر", f"حذف پژوهش‌های {uid}")
    await notify_user(uid, "🔬 پروژه‌ها و پژوهش‌های شما توسط ادمین حذف شد.")
    await call.answer("✅ پژوهش‌ها حذف شد")
    await user_card(call, uid)


@router.callback_query(F.data.startswith("a|ueq|"))
async def user_clear_equip(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    await db.execute("DELETE FROM player_assets WHERE user_id=? AND item_type='equipment'", (uid,))
    await db.execute("DELETE FROM player_assets WHERE user_id=? AND item_type='soldier'", (uid,))
    await log_action(call.from_user.id, "کاربر", f"حذف تجهیزات {uid}")
    await notify_user(uid, "🪖 تجهیزات و سربازان شما توسط ادمین حذف شد.")
    await call.answer("✅ تجهیزات حذف شد")
    await user_card(call, uid)


@router.callback_query(F.data.startswith("a|ureset|"))
async def user_reset(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    user = await db.fetchone("SELECT * FROM users WHERE id=?", (uid,))
    if not user:
        return await call.answer("کاربر یافت نشد", show_alert=True)
    if user["country_id"]:
        await db.execute("UPDATE countries SET owner_id=NULL WHERE owner_id=?", (uid,))
    await db.execute(
        "UPDATE users SET country_id=NULL, country_taken_at=NULL, royal_coins=0, money=50000000, banned=0 "
        "WHERE id=?", (uid,))
    await db.execute("DELETE FROM player_assets WHERE user_id=?", (uid,))
    await db.execute("DELETE FROM player_projects WHERE user_id=?", (uid,))
    await db.execute("DELETE FROM soldier_trainings WHERE user_id=?", (uid,))
    await db.execute("DELETE FROM companies WHERE owner_id=?", (uid,))
    await db.execute("DELETE FROM bases WHERE guest_id=? OR host_id=?", (uid, uid))
    await db.execute("DELETE FROM states WHERE user_id=?", (uid,))
    await log_action(call.from_user.id, "کاربر", f"ریست کامل {uid}")
    await notify_user(uid, "♻️ اکانت شما توسط ادمین کامل ریست شد.")
    await call.answer("♻️ ریست شد")
    await user_card(call, uid)


@router.callback_query(F.data.startswith("a|umsg|"))
async def user_message(call: CallbackQuery, state: FSMContext, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    await state.set_state(UserFSM.message)
    await state.update_data(uid=uid)
    await call.answer()
    await call.message.edit_text(
        f"✉️ پیام خصوصی برای کاربر <code>{uid}</code> را بفرستید (متن):\n برای انصراف /cancel")


@router.message(UserFSM.message)
async def user_message_input(message: Message, state: FSMContext):
    data = await state.get_data()
    await state.clear()
    text = (message.text or "").strip()
    if not text:
        return await message.answer("❌ متن خالی است.")
    ok = await notify_user(data["uid"], f"📬 پیام از پشتیبانی:\n\n{text}")
    await log_action(message.from_user.id, "کاربر", f"پیام به {data['uid']}")
    await message.answer("✅ ارسال شد." if ok else
                         "⚠️ ارسال نشد — کاربر ربات اصلی را استارت نکرده یا بلاکش کرده.")
    await user_card(_FakeCall(message), data["uid"])


@router.callback_query(F.data.startswith("a|urcp|"))
async def user_receipts(call: CallbackQuery, perms: set):
    if not has(perms, "users"):
        return await call.answer("⛔️ دسترسی ندارید", show_alert=True)
    uid = int(call.data.split("|")[2])
    rows = await db.fetchall(
        "SELECT * FROM receipts WHERE user_id=? ORDER BY id DESC LIMIT 10", (uid,))
    lines = [f"🧾 <b>فیش‌های کاربر {uid}</b>\n"]
    if not rows:
        lines.append("— ندارد —")
    for r in rows:
        what = f"کشور(#{r['country_id']})" if r["kind"] == "country" else f"{fmt(r['coins'])} سکه"
        lines.append(f"#{r['id']} {what} — {fmt(r['toman'])} تومان — {r['status']} — "
                     f"{tehran(r['created_at'])}")
    await call.answer()
    await call.message.edit_text("\n".join(lines), reply_markup=kb([
        [("◀️ پروفایل کاربر", f"a|ucard|{uid}")]]))


class _FakeCall:
    def __init__(self, message: Message):
        self.message = message
        self.from_user = message.from_user
        self.bot = message.bot

    async def answer(self, *_a, **_k):
        pass
