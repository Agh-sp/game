"""ربات ادمین — ساخت Dispatcher و اجرا."""
import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.fsm.storage.memory import MemoryStorage

from adminbot.auth import AdminGate
from core.config import ADMIN_BOT_TOKEN, check_tokens
from core.db import init_db

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
log = logging.getLogger("adminbot")


async def _on_startup(bot: Bot) -> None:
    """زمان‌بند ربات ادمین — گزارش روزانه رویدادهای ۲۴ ساعت اخیر."""
    from core.scheduler import start_admin_scheduler
    start_admin_scheduler(bot)


def create_dispatcher() -> Dispatcher:
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.outer_middleware(AdminGate())
    dp.startup.register(_on_startup)
    from adminbot.handlers import (admins, broadcast, logs, panel, receipts,
                                   settings, tickets, users, media, seasons,
                                   sections, prices, equipment_bulk, currency)
    from adminbot import crud
    for r in (panel, users, receipts, tickets, broadcast, admins, settings, logs,
              media, seasons, sections, prices, equipment_bulk, currency, crud):
        dp.include_router(r.router)
    return dp


async def run() -> None:
    check_tokens(admin=True)
    await init_db()
    bot = Bot(ADMIN_BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
    dp = create_dispatcher()
    me = await bot.get_me()
    log.info("🛡 ربات ادمین: @%s", me.username)
    await dp.start_polling(bot, handle_signals=False)


if __name__ == "__main__":
    asyncio.run(run())
