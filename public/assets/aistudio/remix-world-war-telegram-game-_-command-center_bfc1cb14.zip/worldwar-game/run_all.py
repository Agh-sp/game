"""اجرای هر دو ربات در یک پروسه (ربات اصلی بازی + ربات ادمین)."""
import asyncio
import logging

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties

from adminbot.main import create_dispatcher as create_admin_dp
from core.config import ADMIN_BOT_TOKEN, GAME_BOT_TOKEN, check_tokens
from core.db import init_db
from gamebot.main import create_dispatcher as create_game_dp

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s")
log = logging.getLogger("main")


async def run_all() -> None:
    check_tokens(admin=True)
    await init_db()
    game_bot = Bot(GAME_BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
    admin_bot = Bot(ADMIN_BOT_TOKEN, default=DefaultBotProperties(parse_mode="HTML"))
    game_dp = create_game_dp()
    admin_dp = create_admin_dp()
    me1 = await game_bot.get_me()
    me2 = await admin_bot.get_me()
    log.info("🎮 ربات اصلی: @%s | 🛡 ربات ادمین: @%s", me1.username, me2.username)
    await asyncio.gather(
        game_dp.start_polling(game_bot, handle_signals=False),
        admin_dp.start_polling(admin_bot, handle_signals=False),
    )


if __name__ == "__main__":
    asyncio.run(run_all())
