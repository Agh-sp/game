#!/usr/bin/env python3
"""
World War Game Database Bridge
Provides JSON-based SQLite queries and Firebase Realtime Database bi-directional sync
"""

import sys
import os
import json
import sqlite3
import urllib.request
import urllib.error
from datetime import datetime

DB_PATH = os.environ.get('DB_PATH', os.path.join(os.path.dirname(__file__), 'wwgame.db'))
ENV_PATH = os.path.join(os.path.dirname(__file__), '.env')

def load_env():
    env_vars = {}
    if os.path.exists(ENV_PATH):
        try:
            with open(ENV_PATH, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.trim() if hasattr(line, 'trim') else line.strip()
                    if line and not line.startswith('#') and '=' in line:
                        k, v = line.split('=', 1)
                        env_vars[k.strip()] = v.strip()
        except Exception:
            pass
    return env_vars

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def firebase_request(method, path, data=None):
    env_vars = load_env()
    base_url = env_vars.get('FIREBASE_DB_URL') or os.environ.get('FIREBASE_DB_URL', '')
    auth = env_vars.get('FIREBASE_AUTH') or os.environ.get('FIREBASE_AUTH', '')
    
    if not base_url:
        return None
        
    clean_url = base_url.rstrip('/')
    url = f"{clean_url}/{path.lstrip('/')}.json"
    if auth:
        url += f"?auth={auth}"
        
    try:
        req_data = None
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
        if data is not None:
            req_data = json.dumps(data, ensure_ascii=False).encode('utf-8')
            
        req = urllib.request.Request(url, data=req_data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read().decode('utf-8')
            return json.loads(content) if content else None
    except Exception as e:
        sys.stderr.write(f"Firebase error: {str(e)}\n")
        return None

def sync_from_firebase():
    """Import users and states from Firebase Realtime Database into SQLite"""
    fb_users = firebase_request('GET', 'game/users')
    fb_states = firebase_request('GET', 'game/states')
    
    conn = get_conn()
    cur = conn.cursor()
    synced_users = 0
    synced_states = 0
    
    if fb_users and isinstance(fb_users, dict):
        for uid_str, u in fb_users.items():
            if not u or not isinstance(u, dict):
                continue
            uid = int(u.get('id') or uid_str)
            cur.execute("""
                INSERT INTO users (id, username, full_name, joined_at, royal_coins, money, country_id, country_taken_at, banned)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    username = excluded.username,
                    full_name = excluded.full_name,
                    royal_coins = excluded.royal_coins,
                    money = excluded.money,
                    country_id = excluded.country_id,
                    country_taken_at = excluded.country_taken_at,
                    banned = excluded.banned
            """, (
                uid,
                u.get('username', ''),
                u.get('full_name', ''),
                u.get('joined_at', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                int(u.get('royal_coins', 0)),
                int(u.get('money', 50000000)),
                u.get('country_id'),
                u.get('country_taken_at'),
                int(u.get('banned', 0))
            ))
            synced_users += 1

    if fb_states and isinstance(fb_states, dict):
        for uid_str, s in fb_states.items():
            if not s or not isinstance(s, dict):
                continue
            uid = int(s.get('user_id') or uid_str)
            cur.execute("""
                INSERT INTO states (user_id, satisfaction, currency_name, cyber_power)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id) DO UPDATE SET
                    satisfaction = excluded.satisfaction,
                    currency_name = excluded.currency_name,
                    cyber_power = excluded.cyber_power
            """, (
                uid,
                float(s.get('satisfaction', 50.0)),
                s.get('currency_name', 'ریال'),
                int(s.get('cyber_power', 10000))
            ))
            synced_states += 1

    conn.commit()
    conn.close()
    return {"synced_users": synced_users, "synced_states": synced_states}

def push_user_to_firebase(user_id):
    """Push single user and state to Firebase game/users and game/states"""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    u = cur.fetchone()
    if not u:
        conn.close()
        return
        
    user_dict = dict(u)
    firebase_request('PUT', f'game/users/{user_id}', user_dict)
    
    cur.execute("SELECT * FROM states WHERE user_id = ?", (user_id,))
    s = cur.fetchone()
    if s:
        state_dict = dict(s)
        firebase_request('PUT', f'game/states/{user_id}', state_dict)
        
    conn.close()

def get_countries():
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id, name, flag, is_special, coin_price, toman_price, population, has_sea, region, owner_id FROM countries ORDER BY id ASC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows

def get_users():
    # If users table is empty, auto-sync from Firebase first
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) FROM users")
    count = cur.fetchone()[0]
    conn.close()
    
    if count == 0:
        try:
            sync_from_firebase()
        except Exception:
            pass
            
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT 
            u.id,
            u.username,
            u.full_name,
            u.joined_at,
            u.royal_coins,
            u.money,
            u.country_id,
            u.country_taken_at,
            u.banned,
            c.name as country_name,
            c.flag as country_flag,
            s.satisfaction,
            s.cyber_power,
            s.currency_name,
            a.is_super as is_super_admin,
            CASE WHEN a.id IS NOT NULL THEN 1 ELSE 0 END as is_admin,
            a.perms as admin_perms
        FROM users u
        LEFT JOIN countries c ON u.country_id = c.id
        LEFT JOIN states s ON u.id = s.user_id
        LEFT JOIN admins a ON u.id = a.id
        ORDER BY u.joined_at DESC
    """)
    users = [dict(r) for r in cur.fetchall()]
    
    # Also find admins who might not be in users table yet
    cur.execute("""
        SELECT a.id, a.name, a.is_super, a.perms, a.added_at
        FROM admins a
        WHERE a.id NOT IN (SELECT id FROM users)
    """)
    orphan_admins = cur.fetchall()
    for oa in orphan_admins:
        users.append({
            "id": oa['id'],
            "username": "",
            "full_name": oa['name'] or 'مدیر سیستم',
            "joined_at": oa['added_at'],
            "royal_coins": 0,
            "money": 0,
            "country_id": None,
            "country_name": "نامشخص",
            "country_flag": "👑",
            "country_taken_at": None,
            "banned": 0,
            "satisfaction": 100,
            "cyber_power": 10000,
            "currency_name": "ریال",
            "is_super_admin": oa['is_super'],
            "is_admin": 1,
            "admin_perms": oa['perms']
        })
        
    conn.close()
    return users

def get_user_detail(user_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        SELECT 
            u.*,
            c.name as country_name,
            c.flag as country_flag,
            c.population,
            c.has_sea,
            c.oil_reserve,
            s.satisfaction,
            s.cyber_power,
            s.currency_name,
            s.tax_rate,
            s.subsidy_daily,
            a.is_super as is_super_admin,
            CASE WHEN a.id IS NOT NULL THEN 1 ELSE 0 END as is_admin,
            a.perms as admin_perms
        FROM users u
        LEFT JOIN countries c ON u.country_id = c.id
        LEFT JOIN states s ON u.id = s.user_id
        LEFT JOIN admins a ON u.id = a.id
        WHERE u.id = ?
    """, (user_id,))
    row = cur.fetchone()
    if not row:
        conn.close()
        return None
    user_data = dict(row)
    
    # Get user assets
    cur.execute("""
        SELECT pa.*, eq.name as equip_name, eq.emoji as equip_emoji, eq.attack_power, eq.defense_power
        FROM player_assets pa
        LEFT JOIN equipment eq ON pa.item_id = eq.id
        WHERE pa.user_id = ?
    """, (user_id,))
    user_data['assets'] = [dict(r) for r in cur.fetchall()]
    
    # Get user receipts
    cur.execute("SELECT * FROM receipts WHERE user_id = ? ORDER BY id DESC LIMIT 5", (user_id,))
    user_data['receipts'] = [dict(r) for r in cur.fetchall()]
    
    # Get user tickets
    cur.execute("SELECT * FROM tickets WHERE user_id = ? ORDER BY id DESC LIMIT 5", (user_id,))
    user_data['tickets'] = [dict(r) for r in cur.fetchall()]
    
    conn.close()
    return user_data

def update_user(user_id, data):
    conn = get_conn()
    cur = conn.cursor()
    
    # Update users table
    cur.execute("""
        UPDATE users
        SET 
            username = COALESCE(?, username),
            full_name = COALESCE(?, full_name),
            royal_coins = COALESCE(?, royal_coins),
            money = COALESCE(?, money),
            country_id = COALESCE(?, country_id),
            banned = COALESCE(?, banned)
        WHERE id = ?
    """, (
        data.get('username'),
        data.get('full_name'),
        data.get('royal_coins'),
        data.get('money'),
        data.get('country_id'),
        data.get('banned'),
        user_id
    ))
    
    # If state fields present, update states table
    if 'satisfaction' in data or 'cyber_power' in data:
        cur.execute("""
            INSERT INTO states (user_id, satisfaction, cyber_power)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                satisfaction = COALESCE(?, satisfaction),
                cyber_power = COALESCE(?, cyber_power)
        """, (
            user_id,
            data.get('satisfaction', 50.0),
            data.get('cyber_power', 10000),
            data.get('satisfaction'),
            data.get('cyber_power')
        ))
        
    conn.commit()
    conn.close()
    
    # Push update to Firebase in background
    try:
        push_user_to_firebase(user_id)
    except Exception:
        pass
        
    return {"success": True, "message": f"کاربر {user_id} با موفقیت به‌روزرسانی شد"}

def add_user(data):
    user_id = int(data.get('id'))
    username = data.get('username', '').lstrip('@')
    full_name = data.get('full_name', '') or username or f'کاربر {user_id}'
    money = int(data.get('money', 50000000))
    royal_coins = int(data.get('royal_coins', 0))
    country_id = data.get('country_id')
    banned = int(data.get('banned', 0))
    
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO users (id, username, full_name, joined_at, royal_coins, money, country_id, banned)
        VALUES (?, ?, ?, datetime('now'), ?, ?, ?, ?)
        ON CONFLICT(id) DO UPDATE SET
            username = excluded.username,
            full_name = excluded.full_name,
            royal_coins = excluded.royal_coins,
            money = excluded.money,
            country_id = excluded.country_id,
            banned = excluded.banned
    """, (user_id, username, full_name, royal_coins, money, country_id, banned))
    
    # Initialize state
    cur.execute("""
        INSERT INTO states (user_id, satisfaction, cyber_power, currency_name)
        VALUES (?, 50.0, 10000, 'ریال')
        ON CONFLICT(user_id) DO NOTHING
    """, (user_id,))
    
    conn.commit()
    conn.close()
    
    try:
        push_user_to_firebase(user_id)
    except Exception:
        pass
        
    return {"success": True, "message": f"کاربر {full_name} با موفقیت افزوده شد", "id": user_id}

def toggle_ban(user_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT banned FROM users WHERE id = ?", (user_id,))
    row = cur.fetchone()
    new_banned = 1
    if row and row['banned'] == 1:
        new_banned = 0
    cur.execute("UPDATE users SET banned = ? WHERE id = ?", (new_banned, user_id))
    conn.commit()
    conn.close()
    
    try:
        push_user_to_firebase(user_id)
    except Exception:
        pass
        
    return {"success": True, "banned": new_banned, "message": "کاربر مسدود شد" if new_banned == 1 else "کاربر رفع مسدودیت شد"}

def adjust_balance(user_id, money_delta, coins_delta):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("""
        UPDATE users
        SET 
            money = MAX(0, money + ?),
            royal_coins = MAX(0, royal_coins + ?)
        WHERE id = ?
    """, (money_delta, coins_delta, user_id))
    conn.commit()
    conn.close()
    
    try:
        push_user_to_firebase(user_id)
    except Exception:
        pass
        
    return {"success": True, "message": "موجودی با موفقیت تغییر یافت"}

def toggle_admin(user_id, name, is_super):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT id FROM admins WHERE id = ?", (user_id,))
    row = cur.fetchone()
    
    if row:
        cur.execute("DELETE FROM admins WHERE id = ?", (user_id,))
        msg = "دسترسی مدیریت از این کاربر سلب شد"
        is_admin = False
    else:
        cur.execute("""
            INSERT INTO admins (id, name, is_super, perms, added_at)
            VALUES (?, ?, ?, '[]', datetime('now'))
        """, (user_id, name or f'مدیر {user_id}', 1 if is_super else 0))
        msg = "کاربر با موفقیت به عنوان مدیر ثبت شد"
        is_admin = True
        
    conn.commit()
    conn.close()
    return {"success": True, "is_admin": is_admin, "message": msg}

def delete_user(user_id):
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("DELETE FROM users WHERE id = ?", (user_id,))
    cur.execute("DELETE FROM states WHERE user_id = ?", (user_id,))
    cur.execute("DELETE FROM player_assets WHERE user_id = ?", (user_id,))
    conn.commit()
    conn.close()
    
    try:
        firebase_request('DELETE', f'game/users/{user_id}')
        firebase_request('DELETE', f'game/states/{user_id}')
    except Exception:
        pass
        
    return {"success": True, "message": f"کاربر {user_id} حذف شد"}

def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "No command provided"}))
        return
        
    cmd = sys.argv[1]
    
    try:
        if cmd == 'get_users':
            res = get_users()
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'get_countries':
            res = get_countries()
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'get_user':
            user_id = int(sys.argv[2])
            res = get_user_detail(user_id)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'update_user':
            user_id = int(sys.argv[2])
            data = json.loads(sys.argv[3])
            res = update_user(user_id, data)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'add_user':
            data = json.loads(sys.argv[2])
            res = add_user(data)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'toggle_ban':
            user_id = int(sys.argv[2])
            res = toggle_ban(user_id)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'adjust_balance':
            user_id = int(sys.argv[2])
            money_delta = int(sys.argv[3])
            coins_delta = int(sys.argv[4])
            res = adjust_balance(user_id, money_delta, coins_delta)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'toggle_admin':
            user_id = int(sys.argv[2])
            name = sys.argv[3] if len(sys.argv) > 3 else ""
            is_super = int(sys.argv[4]) if len(sys.argv) > 4 else 0
            res = toggle_admin(user_id, name, is_super)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'delete_user':
            user_id = int(sys.argv[2])
            res = delete_user(user_id)
            print(json.dumps(res, ensure_ascii=False))
        elif cmd == 'sync_firebase':
            res = sync_from_firebase()
            print(json.dumps(res, ensure_ascii=False))
        else:
            print(json.dumps({"error": f"Unknown command: {cmd}"}))
    except Exception as e:
        print(json.dumps({"error": str(e), "success": False}))

if __name__ == '__main__':
    main()
